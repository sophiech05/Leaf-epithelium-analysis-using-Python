import tifffile
from scipy import ndimage as ndi
import skimage
from skimage.measure import label
from skimage import measure
import numpy as np
import napari
from typing import List
from magicgui import magicgui
from napari.types import ImageData, LabelsData, LayerDataTuple, PointsData
import glob
import pandas as pd
import os
import csv
from skimage.segmentation import watershed
from sklearn.neighbors import NearestNeighbors
from junction_finder import *


def save_data(filename, centroid_pos):
    header = ['image_fname', 'nb_cells', 'centroids_fname']
    if not os.path.isfile('how_many_cells_database.csv'):
        with open('how_many_cells_database.csv', 'x') as csvfile:  
            writer = csv.DictWriter(csvfile, fieldnames=header)    
            writer.writeheader()  
    
    df = pd.read_csv("how_many_cells_database.csv")
    # updating the column value/data
    df.loc[filename+'.tif'] = [filename+'.tif',len(np.unique(centroid_pos))//2, "cells_centroid-"+filename+'.csv']
    # writing into the file
    df.to_csv("how_many_cells_database.csv", index=False)
    
def save_junction_data(filename, junction_number, nt_junction_number):
    header = ['nb_cells', 'centroids_fname']
    if not os.path.isfile('how_many_cells_database.csv'):
        with open('how_many_cells_database.csv', 'x') as csvfile:  
            writer = csv.DictWriter(csvfile, fieldnames=header)    
            writer.writeheader()  
    
    df = pd.read_csv("how_many_cells_database.csv")
    # updating the column value/data
    df.loc[filename+'.tif'] = [junction_number, "cells_centroid-"+filename+'.csv', nt_junction_number]
    # writing into the file
    df.to_csv("how_many_cells_database.csv", index=False)
    
def save_centroids(filename, centroids):
        centroids = centroids[1:]
        if not os.path.isfile(filename+'.csv'):
            with open(filename+'.csv', 'x') as csvfile:
                centroids.to_csv(filename+'.csv', mode='a', index=True)
                #add line to change header to axis
        else:
            print('already exists')
            return

def get_path():
    print('Please put below the directory of the folder containing your images of interest: ')
    tmp = input()
    fnames = glob.glob(tmp+'/*.tif')
    return fnames

fnames = get_path()

@magicgui(
    fname={"choices": fnames}
) 
def get_image(
    fname=fnames[0]
    ) -> LayerDataTuple:
    # open labeled ground truth img
    raw = tifffile.imread(fname)
    return [(raw[:,:,0], {"name":"raw",'colormap':'gray'}, "image"),]

@magicgui(
    filter_type= {"choices": ["gaussian", "median","no filter"]},
    slider={"widget_type": "FloatSlider", 'max': 10},
    mode={"choices": ["reflect", "constant", "nearest", "mirror", "wrap"]},
) 
def preprocessing(
    img: ImageData, 
    filter_type, 
    slider: float = 1.0, 
    mode = "nearest", 
    local_threshold_block_size:int=150,
    radius_disk_closing:int=1,
    radius_disk_opening:int=8,
    min_size_object:int=150,
    area_filter: bool=False,
    )-> LabelsData:
    if filter_type == "gaussian":
        img =  skimage.filters.gaussian(img, sigma=slider, mode=mode)
    elif filter_type == "median":
        footprint = skimage.morphology.disk(slider) 
        img = skimage.filters.median(img, footprint = footprint, mode = mode)

    if local_threshold_block_size%2 == 0:
        local_threshold_block_size+=1
    local_threshold = skimage.filters.threshold_local(img, block_size=local_threshold_block_size)
    mask = img > local_threshold
    
    mask = skimage.morphology.binary_closing(
        mask, skimage.morphology.disk(radius_disk_closing))
    
    mask = skimage.morphology.remove_small_holes(
        mask, area_threshold=400)

    # Remove small objects
    mask = skimage.morphology.remove_small_objects(
        mask, min_size_object)

    mask = skimage.morphology.binary_opening(
        mask, skimage.morphology.disk(radius_disk_opening))
    
    labeled = label(mask)
        
    return labeled

@magicgui(
    fname={"choices": fnames}
) 
def centroid(
    fname,
    label_objects:LabelsData,
    ) -> PointsData:    
    fname = os.path.splitext(os.path.basename(fname))[0]
    props = measure.regionprops_table(
    label_objects,
    properties=['label', 'centroid'] # properties to be measured
    )
    df_props = pd.DataFrame(props)   # transform into panda table
    df_props.columns = ['label', 'axis-0', 'axis-1']
    # show centroids on the viewer
    centroids = df_props[['axis-0','axis-1']]
    save_centroids("cells_centroid-"+fname, centroids)
    save_data(fname,centroids)
    return centroids

@magicgui 
def skeleton(
    segmentation:LabelsData,
    ) -> LabelsData:
    
    erod = skimage.morphology.binary_erosion(
        segmentation, skimage.morphology.disk(5))
    
    labeled = label(erod)
    
    elev_map = np.ones(labeled.shape, dtype=int)
    
    final = watershed(elev_map,labeled,watershed_line=True)
    final = final < 1
    return final

@magicgui
def junctions(
    skeleton:LabelsData,
    ) -> PointsData:
    shape = skeleton.shape
    
    input_image = skeleton.astype(np.uint8) # must be black and white thin network image
    

    intersections = find_line_intersection(input_image, 0)
    interstections.astype(int)
    
    points = np.nonzero(intersections)
    triangulars = []
    out = []
    for i in np.transpose((points[0], points[1])):
        if i[0]-10 > 0 and i[1]-10 > 0 and i[0]+10 < shape[0] and i[1]+10  < shape[1]:
            outer = skeleton[max(0,i[0]-10):min(i[0]+10,shape[0]),max(0,i[1]-10):min(i[1]+10,shape[1])] #[i[0]:i[0]+5,i[1]:i[1]+5]
            inner = skeleton[max(0,i[0]-9):min(i[0]+9,shape[0]),max(0,i[1]-9):min(i[1]+9,shape[1])]
            inner = np.pad(inner, 1, mode='constant', constant_values=0)
            outer = outer - inner
            #print(label(outer))
            if len(np.unique(label(outer))) > 3:
                triangulars.append(i)
                    
    nearest = NearestNeighbors(n_neighbors= 2, algorithm= "ball_tree").fit(triangulars)
    distances = nearest.kneighbors(triangulars)[0]
    distances = distances[:,1]
    
    for i in range(0,len(distances)):
        if distances[i] < 10 :
            out.append(triangulars[i])
    return out